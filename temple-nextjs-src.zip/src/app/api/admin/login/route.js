import { NextResponse } from "next/server";
import { getAdmin } from "@/lib/store";
import { signSession, sessionCookieOptions, verifyPassword } from "@/lib/auth";

export async function POST(request) {
  let body;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const { password } = body || {};
  if (!password) {
    return NextResponse.json({ error: "Password is required" }, { status: 400 });
  }

  const admin = getAdmin();
  const ok = await verifyPassword(password, admin.passwordHash);
  if (!ok) {
    return NextResponse.json({ error: "Incorrect password" }, { status: 401 });
  }

  const maxAge = 60 * 60 * 12; // 12 hours, matches token TTL
  const token = signSession();
  const res = NextResponse.json({ ok: true });
  res.cookies.set({
    ...sessionCookieOptions(maxAge),
    value: token,
  });
  return res;
}
