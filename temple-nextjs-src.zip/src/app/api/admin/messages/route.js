import { NextResponse } from "next/server";
import { getMessages } from "@/lib/store";
import { isAuthed } from "@/lib/auth";

export async function GET() {
  if (!(await isAuthed())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const messages = getMessages();
  return NextResponse.json(messages);
}
