import { NextResponse } from "next/server";
import { getAdmin, saveAdmin } from "@/lib/store";
import { hashPassword, isAuthed } from "@/lib/auth";

export async function PUT(request) {
  if (!(await isAuthed())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  let body;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const { newPassword } = body || {};
  if (!newPassword || newPassword.length < 4) {
    return NextResponse.json(
      { error: "Password must be at least 4 characters" },
      { status: 400 }
    );
  }

  const admin = getAdmin();
  admin.passwordHash = await hashPassword(newPassword);
  saveAdmin(admin);

  return NextResponse.json({ ok: true });
}
