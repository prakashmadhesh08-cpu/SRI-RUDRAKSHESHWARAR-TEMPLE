import { NextResponse } from "next/server";
import { resetContent } from "@/lib/store";
import { isAuthed } from "@/lib/auth";

export async function POST() {
  if (!(await isAuthed())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const content = resetContent();
  return NextResponse.json(content);
}
