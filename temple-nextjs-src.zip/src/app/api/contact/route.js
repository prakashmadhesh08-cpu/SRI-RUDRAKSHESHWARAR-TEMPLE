import { NextResponse } from "next/server";
import { nanoid } from "nanoid";
import { addMessage } from "@/lib/store";

export async function POST(request) {
  let body;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const { name, email, phone, message } = body || {};
  if (!name || !message) {
    return NextResponse.json(
      { error: "Name and message are required" },
      { status: 400 }
    );
  }

  const record = {
    id: nanoid(10),
    name: String(name).slice(0, 200),
    email: email ? String(email).slice(0, 200) : "",
    phone: phone ? String(phone).slice(0, 40) : "",
    message: String(message).slice(0, 5000),
    createdAt: new Date().toISOString(),
    read: false,
  };

  addMessage(record);
  return NextResponse.json({ ok: true });
}
