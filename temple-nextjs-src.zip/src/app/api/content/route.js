import { NextResponse } from "next/server";
import { getContent, saveContent } from "@/lib/store";
import { isAuthed } from "@/lib/auth";

export async function GET() {
  const content = getContent();
  return NextResponse.json(content);
}

export async function PUT(request) {
  if (!(await isAuthed())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  let body;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  if (!body || typeof body !== "object") {
    return NextResponse.json({ error: "Content must be an object" }, { status: 400 });
  }

  const saved = saveContent(body);
  return NextResponse.json(saved);
}
