import "./globals.css";

export const metadata = {
  metadataBase: new URL("https://rudraksheshwarar.org"),
  title: "Rudraksheshwarar Shiva Temple — Thepperumanallur Snake Temple | Marupuruvila Sivasthalam",
  description:
    "Rudraksheshwarar Shiva Temple, Thepperumanallur — ancient Marupuruvila Sivasthalam, sacred Snake Temple near Kumbakonam, Tamil Nadu. Daily poojas, Abhishekam, festivals.",
  keywords:
    "Rudraksheshwarar Temple, Thepperumanallur Shiva Temple, Snake Temple Tamil Nadu, Marupuruvila Sivasthalam, Kumbakonam Temple, Sarpa Dosha Temple, Naga Temple Tamil Nadu",
  openGraph: {
    type: "website",
    title: "Rudraksheshwarar Shiva Temple — Sacred Snake Temple, Thepperumanallur",
    description:
      "Ancient Marupuruvila Sivasthalam — sacred Shiva Temple near Kumbakonam, Tamil Nadu.",
    url: "https://rudraksheshwarar.org/",
    siteName: "Rudraksheshwarar Shiva Temple",
    locale: "en_IN",
  },
  twitter: {
    card: "summary_large_image",
    title: "Rudraksheshwarar Shiva Temple — Thepperumanallur",
    description: "Sacred Snake Temple near Kumbakonam. Daily poojas, Abhishekam and blessings for all devotees.",
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" dir="ltr">
      <body>{children}</body>
    </html>
  );
}
