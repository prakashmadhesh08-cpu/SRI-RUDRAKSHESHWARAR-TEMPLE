import { getContent } from "@/lib/store";
import ThemeStyle from "@/components/ThemeStyle";
import Header from "@/components/Header";
import Hero from "@/components/Hero";
import About from "@/components/About";
import ContactBanner from "@/components/ContactBanner";
import History from "@/components/History";
import Gallery from "@/components/Gallery";
import Videos from "@/components/Videos";
import Festivals from "@/components/Festivals";
import Updates from "@/components/Updates";
import Donations from "@/components/Donations";
import Contact from "@/components/Contact";
import Location from "@/components/Location";
import Footer from "@/components/Footer";

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "PlaceOfWorship",
  name: "Rudraksheshwarar Shiva Temple",
  alternateName: [
    "Thepperumanallur Shiva Temple",
    "Marupuruvila Sivasthalam",
    "Snake Temple Thepperumanallur",
  ],
  description:
    "Ancient Shiva temple at Thepperumanallur, known as Marupuruvila Sivasthalam — sacred Snake Temple near Kumbakonam, Tamil Nadu.",
  url: "https://rudraksheshwarar.org",
  religion: "Hinduism",
  deity: "Lord Shiva / Rudraksheshwarar",
};

export default function HomePage() {
  const content = getContent();

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <ThemeStyle theme={content.theme} />
      <Header />
      <main>
        <Hero hero={content.hero} />
        <About about={content.about} significance={content.significance} />
        <ContactBanner phones={content.phones} />
        <History history={content.history} importance={content.importance} />
        <Gallery gallery={content.gallery} />
        <Videos videos={content.videos} />
        <Festivals festivals={content.festivals} />
        <Updates updates={content.updates} />
        {!content.donations?.hidden && <Donations donations={content.donations} />}
        <Contact contact={content.contact} phones={content.phones} />
        <Location location={content.location} />
      </main>
      <Footer contact={content.contact} />
    </>
  );
}
