export default function About({ about, significance }) {
  return (
    <section className="sec" id="about">
      <div className="wrap">
        <div className="grid-2">
          <div>
            <div className="eyebrow">Welcome</div>
            <h2 className="sec-title">About The Temple</h2>
            <p className="sec-lead" style={{ marginBottom: 20 }}>{about?.text}</p>
          </div>
          {about?.image && (
            <img
              src={about.image}
              alt="Temple architecture"
              style={{ borderRadius: "var(--r-lg)", boxShadow: "var(--shadow-lg)", width: "100%" }}
            />
          )}
        </div>

        {significance?.items?.length > 0 && (
          <div className="grid-3" style={{ marginTop: 64 }}>
            {significance.items.map((s, i) => (
              <div className="sig-card" key={i}>
                <div className="sig-top">
                  <div className="s-icon">{s.icon}</div>
                  <h3>{s.title}</h3>
                </div>
                <div className="sig-body">{s.body}</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
