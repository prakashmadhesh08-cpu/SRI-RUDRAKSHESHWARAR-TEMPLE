"use client";

import { useState } from "react";

export default function Contact({ contact, phones }) {
  const [form, setForm] = useState({ name: "", email: "", phone: "", message: "" });
  const [status, setStatus] = useState("idle"); // idle | sending | sent | error

  async function handleSubmit(e) {
    e.preventDefault();
    setStatus("sending");
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (!res.ok) throw new Error("failed");
      setStatus("sent");
      setForm({ name: "", email: "", phone: "", message: "" });
    } catch {
      setStatus("error");
    }
  }

  return (
    <section className="sec sec-alt" id="contact">
      <div className="wrap">
        <div className="sec-head">
          <div className="eyebrow" style={{ justifyContent: "center" }}>Reach Us</div>
          <h2 className="sec-title">Contact</h2>
        </div>
        <div className="grid-2">
          <form className="contact-form" onSubmit={handleSubmit}>
            <input
              type="text" placeholder="Your Name" required
              value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })}
            />
            <input
              type="email" placeholder="Your Email"
              value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })}
            />
            <input
              type="tel" placeholder="Phone Number"
              value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })}
            />
            <textarea
              placeholder="Your Message" rows={5} required
              value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })}
            />
            <button type="submit" className="btn btn-primary" disabled={status === "sending"}>
              {status === "sending" ? "Sending…" : "Send Message"}
            </button>
            {status === "sent" && <p style={{ color: "var(--green)", fontSize: 13 }}>Thank you — your message has been sent.</p>}
            {status === "error" && <p style={{ color: "var(--primary2)", fontSize: 13 }}>Something went wrong. Please try again.</p>}
          </form>

          <div>
            {contact?.email && (
              <div className="contact-info-item">
                <div className="contact-info-icon">✉</div>
                <div><strong>Email</strong><br />{contact.email}</div>
              </div>
            )}
            {contact?.address && (
              <div className="contact-info-item">
                <div className="contact-info-icon">📍</div>
                <div><strong>Address</strong><br style={{ whiteSpace: "pre-line" }} />{contact.address}</div>
              </div>
            )}
            {contact?.hours && (
              <div className="contact-info-item">
                <div className="contact-info-icon">🕐</div>
                <div><strong>Visiting Hours</strong><br />{contact.hours}</div>
              </div>
            )}
            {phones?.length > 0 && (
              <div className="contact-info-item">
                <div className="contact-info-icon">📞</div>
                <div>
                  <strong>Phone</strong><br />
                  {phones.map((p, i) => <div key={i}>{p.label}: {p.number}</div>)}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
