function waUrl(v) {
  if (!v) return null;
  const s = String(v).trim();
  if (s.startsWith("http")) return s;
  return `https://wa.me/${s.replace(/[^0-9]/g, "")}`;
}

export default function ContactBanner({ phones }) {
  if (!phones?.length) return null;

  return (
    <section className="contact-banner" id="contact-banner">
      <div className="wrap">
        <div className="cb-grid">
          {phones.map((p, i) => (
            <div className="cb-item" key={i}>
              <div className="cb-label">{p.label}</div>
              <a href={`tel:${p.number.replace(/[^0-9+]/g, "")}`}>
                <div className="cb-number">{p.number}</div>
              </a>
              {p.desc && <div className="cb-desc">{p.desc}</div>}
              {p.whatsapp && (
                <a
                  href={waUrl(p.whatsapp)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn btn-green"
                  style={{ marginTop: 10, padding: "8px 16px", fontSize: 12 }}
                >
                  WhatsApp
                </a>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
