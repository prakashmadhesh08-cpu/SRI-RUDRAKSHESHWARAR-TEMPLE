export default function Donations({ donations }) {
  return (
    <section className="sec" id="donations">
      <div className="wrap">
        <div className="sec-head">
          <div className="eyebrow" style={{ justifyContent: "center" }}>Support The Temple</div>
          <h2 className="sec-title">Donations</h2>
        </div>
        <div className="donation-box">
          <p className="sec-lead" style={{ margin: "0 auto 8px" }}>{donations?.text}</p>
          {donations?.upi && <div className="donation-upi">{donations.upi}</div>}
          {donations?.qr && <img className="donation-qr" src={donations.qr} alt="Donation QR code" />}
        </div>
      </div>
    </section>
  );
}
