export default function Festivals({ festivals }) {
  if (!festivals?.length) return null;

  return (
    <section className="sec" id="festivals">
      <div className="wrap">
        <div className="sec-head">
          <div className="eyebrow" style={{ justifyContent: "center" }}>Celebrations</div>
          <h2 className="sec-title">Festivals &amp; Occasions</h2>
        </div>
        <div className="grid-4">
          {festivals.map((f, i) => (
            <div className="fest-card" key={i}>
              <div className="fest-icon">{f.icon}</div>
              <div className="fest-name">{f.name}</div>
              <div className="fest-date">{f.date}</div>
              <p className="fest-desc">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
