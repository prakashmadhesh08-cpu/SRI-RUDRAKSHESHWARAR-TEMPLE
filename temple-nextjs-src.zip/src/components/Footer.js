export default function Footer({ contact }) {
  const year = new Date().getFullYear();

  return (
    <footer className="site-footer">
      <div className="wrap">
        <div className="footer-grid">
          <div>
            <div className="footer-brand">Rudraksheshwarar Shiva Temple</div>
            <p style={{ fontSize: 13, maxWidth: 320 }}>
              Thepperumanallur Snake Temple — Marupuruvila Sivasthalam, near Kumbakonam, Tamil Nadu.
            </p>
          </div>
          <div className="footer-links">
            <strong style={{ color: "#fff", fontSize: 13 }}>Quick Links</strong>
            <a href="#about">About</a>
            <a href="#history">History</a>
            <a href="#gallery">Gallery</a>
            <a href="#contact">Contact</a>
          </div>
          <div className="footer-links">
            <strong style={{ color: "#fff", fontSize: 13 }}>Contact</strong>
            {contact?.email && <span style={{ display: "block", padding: "4px 0", fontSize: 13 }}>{contact.email}</span>}
            {contact?.hours && <span style={{ display: "block", padding: "4px 0", fontSize: 13 }}>{contact.hours}</span>}
          </div>
        </div>
        <div className="footer-bottom">
          © {year} Rudraksheshwarar Shiva Temple. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
