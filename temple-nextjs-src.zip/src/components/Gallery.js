"use client";

import { useState } from "react";

export default function Gallery({ gallery }) {
  const [active, setActive] = useState(null);

  if (!gallery?.length) return null;

  return (
    <section className="sec" id="gallery">
      <div className="wrap">
        <div className="sec-head">
          <div className="eyebrow" style={{ justifyContent: "center" }}>Sacred Moments</div>
          <h2 className="sec-title">Temple Gallery</h2>
        </div>
        <div className="gal-grid">
          {gallery.map((g, i) => (
            <div className="gal-item" key={i} onClick={() => setActive(g.url)}>
              <img src={g.url} alt={g.cap} loading="lazy" />
              <div className="gal-overlay">
                <span className="gal-cap">{g.cap}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className={`lightbox${active ? " open" : ""}`} onClick={() => setActive(null)}>
        <button className="lb-close" onClick={() => setActive(null)} aria-label="Close">✕</button>
        {active && <img src={active} alt="" onClick={(e) => e.stopPropagation()} />}
      </div>
    </section>
  );
}
