export default function Hero({ hero }) {
  return (
    <section className="hero" id="hero">
      <img className="hero-img" src={hero?.image} alt="Rudraksheshwarar Shiva Temple" />
      <div className="hero-overlay" />
      <div className="hero-content">
        <h1 className="hero-title">Rudraksheshwarar Shiva Temple</h1>
        <p className="hero-welcome">{hero?.welcome}</p>
        <div className="hero-cta">
          <a href="#about" className="btn btn-gold">Explore The Temple</a>
          <a href="#contact" className="btn btn-outline" style={{ borderColor: "#fff", color: "#fff" }}>
            Contact Us
          </a>
        </div>
      </div>
    </section>
  );
}
