export default function History({ history, importance }) {
  return (
    <section className="sec sec-alt" id="history">
      <div className="wrap">
        <div className="sec-head">
          <div className="temple-divider"><span className="td-line" /><span className="td-icon">🕉️</span><span className="td-line" /></div>
          <div className="eyebrow" style={{ justifyContent: "center" }}>Our Heritage</div>
          <h2 className="sec-title">History &amp; Legend</h2>
        </div>
        <div className="grid-2">
          <div>
            <h3 style={{ fontFamily: "var(--font-display)", marginBottom: 12 }}>The Sacred Origin</h3>
            {history?.text?.split("\n\n").map((p, i) => (
              <p key={i} className="sec-lead" style={{ maxWidth: "none", marginBottom: 16 }}>{p}</p>
            ))}
          </div>
          <div>
            <h3 style={{ fontFamily: "var(--font-display)", marginBottom: 12 }}>Spiritual Importance</h3>
            {importance?.text?.split("\n\n").map((p, i) => (
              <p key={i} className="sec-lead" style={{ maxWidth: "none", marginBottom: 16 }}>{p}</p>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
