export default function Location({ location }) {
  return (
    <section className="sec" id="location">
      <div className="wrap">
        <div className="sec-head">
          <div className="eyebrow" style={{ justifyContent: "center" }}>Find Us</div>
          <h2 className="sec-title">Location &amp; Directions</h2>
          {location?.landmark && <p className="sec-lead">{location.landmark}</p>}
        </div>
        {location?.map && (
          <iframe className="map-embed" src={location.map} loading="lazy" title="Temple location map" />
        )}
        {location?.directions && (
          <div style={{ textAlign: "center", marginTop: 24 }}>
            <a href={location.directions} target="_blank" rel="noopener noreferrer" className="btn btn-primary">
              Get Directions
            </a>
          </div>
        )}
      </div>
    </section>
  );
}
