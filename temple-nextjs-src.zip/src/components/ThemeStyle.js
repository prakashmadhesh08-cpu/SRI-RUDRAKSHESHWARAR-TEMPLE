export default function ThemeStyle({ theme }) {
  if (!theme) return null;

  const vars = {
    "--primary": theme.primary,
    "--primary2": theme.primary2,
    "--gold": theme.gold,
    "--stone": theme.stone,
    "--stone2": theme.stone2,
    "--cream": theme.cream,
    "--sand": theme.sand,
    "--border": theme.border,
    "--muted": theme.muted,
  };

  const css = `:root{${Object.entries(vars)
    .filter(([, v]) => v)
    .map(([k, v]) => `${k}:${v};`)
    .join("")}}`;

  return <style dangerouslySetInnerHTML={{ __html: css }} />;
}
