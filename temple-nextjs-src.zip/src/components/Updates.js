export default function Updates({ updates }) {
  if (!updates?.length) return null;

  return (
    <section className="sec sec-alt" id="updates">
      <div className="wrap" style={{ maxWidth: 720 }}>
        <div className="sec-head">
          <div className="eyebrow" style={{ justifyContent: "center" }}>Stay Informed</div>
          <h2 className="sec-title">Latest Updates</h2>
        </div>
        <div>
          {updates.map((u, i) => (
            <div className="update-item" key={i}>
              <div className="upd-date-box">
                <div className="upd-day">{u.day}</div>
                <div className="upd-mon">{u.mon}</div>
              </div>
              <div>
                <span className="upd-tag">{u.tag}</span>
                <div className="upd-title">{u.title}</div>
                <div className="upd-text">{u.text}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
