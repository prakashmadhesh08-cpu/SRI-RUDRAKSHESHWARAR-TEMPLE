"use client";

import { useState } from "react";

function extractYTId(url) {
  if (!url) return null;
  const m = url.match(/(?:youtube\.com\/(?:embed\/|watch\?v=)|youtu\.be\/)([\w-]{6,})/);
  return m ? m[1] : null;
}

function VideoCard({ v }) {
  const [playing, setPlaying] = useState(false);

  if (v.type === "youtube") {
    const id = extractYTId(v.url);
    const thumb = id ? `https://img.youtube.com/vi/${id}/hqdefault.jpg` : null;

    return (
      <div className="vid-card">
        <div className="vid-card-thumb" onClick={() => setPlaying(true)}>
          {playing ? (
            <iframe src={v.url} title={v.title} allowFullScreen loading="lazy" />
          ) : thumb ? (
            <>
              <img src={thumb} alt={v.title} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
              <div className="play-overlay"><div className="play-btn">▶</div></div>
            </>
          ) : (
            <iframe src={v.url} title={v.title} allowFullScreen loading="lazy" />
          )}
        </div>
        <div className="vid-card-info">
          <div className="vid-card-title">{v.title}</div>
          <div className="vid-card-type">YouTube Video</div>
        </div>
      </div>
    );
  }

  return (
    <div className="vid-card">
      <div className="vid-card-thumb">
        <video controls src={v.url} style={{ width: "100%", height: "100%" }} preload="metadata" />
      </div>
      <div className="vid-card-info">
        <div className="vid-card-title">{v.title}</div>
        <div className="vid-card-type">Uploaded Video</div>
      </div>
    </div>
  );
}

export default function Videos({ videos }) {
  return (
    <section className="sec sec-alt" id="videos">
      <div className="wrap">
        <div className="sec-head">
          <div className="eyebrow" style={{ justifyContent: "center" }}>Watch &amp; Experience</div>
          <h2 className="sec-title">Temple Videos</h2>
        </div>
        {!videos?.length ? (
          <p style={{ textAlign: "center", color: "var(--muted)", padding: 40 }}>
            No videos added yet. Add videos from the Admin Panel.
          </p>
        ) : (
          <div className="vid-grid">
            {videos.map((v, i) => <VideoCard v={v} key={i} />)}
          </div>
        )}
      </div>
    </section>
  );
}
