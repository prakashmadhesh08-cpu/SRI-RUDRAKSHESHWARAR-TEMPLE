"use client";

import { useEffect, useState } from "react";
import Login from "./Login";
import Dashboard from "./Dashboard";

export default function AdminApp() {
  const [authed, setAuthed] = useState(null); // null = checking

  useEffect(() => {
    fetch("/api/admin/session")
      .then((r) => r.json())
      .then((d) => setAuthed(!!d.authed))
      .catch(() => setAuthed(false));
  }, []);

  if (authed === null) {
    return <div className="admin-shell"><div className="admin-body">Loading…</div></div>;
  }

  if (!authed) {
    return <Login onLogin={() => setAuthed(true)} />;
  }

  return <Dashboard onLogout={() => setAuthed(false)} />;
}
