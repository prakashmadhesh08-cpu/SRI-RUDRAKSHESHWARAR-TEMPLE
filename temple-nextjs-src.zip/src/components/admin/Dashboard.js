"use client";

import { useEffect, useState } from "react";
import ImageUploader from "./ImageUploader";

const TABS = [
  { key: "hero", label: "Hero" },
  { key: "about", label: "About" },
  { key: "history", label: "History" },
  { key: "significance", label: "Significance" },
  { key: "gallery", label: "Gallery" },
  { key: "videos", label: "Videos" },
  { key: "festivals", label: "Festivals" },
  { key: "updates", label: "Updates" },
  { key: "donations", label: "Donations" },
  { key: "phones", label: "Contact Numbers" },
  { key: "contact", label: "Contact Info" },
  { key: "location", label: "Location" },
  { key: "theme", label: "Theme & Colors" },
  { key: "messages", label: "Messages" },
  { key: "password", label: "Password" },
];

function set(obj, path, value) {
  const clone = structuredClone(obj);
  const keys = path.split(".");
  let cur = clone;
  for (let i = 0; i < keys.length - 1; i++) cur = cur[keys[i]];
  cur[keys[keys.length - 1]] = value;
  return clone;
}

function get(obj, path) {
  return path.split(".").reduce((o, k) => (o == null ? o : o[k]), obj);
}

export default function Dashboard({ onLogout }) {
  const [content, setContent] = useState(null);
  const [tab, setTab] = useState("hero");
  const [messages, setMessages] = useState([]);
  const [toast, setToast] = useState("");

  useEffect(() => {
    fetch("/api/content").then((r) => r.json()).then(setContent);
  }, []);

  useEffect(() => {
    if (tab === "messages") {
      fetch("/api/admin/messages").then((r) => r.json()).then(setMessages);
    }
  }, [tab]);

  function showToast(msg) {
    setToast(msg);
    setTimeout(() => setToast(""), 2800);
  }

  async function saveContent(next) {
    setContent(next);
    const res = await fetch("/api/content", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(next),
    });
    if (res.ok) showToast("✅ Saved successfully!");
    else showToast("⚠️ Save failed");
  }

  async function handleReset() {
    if (!confirm("Restore all content to defaults? This cannot be undone.")) return;
    const res = await fetch("/api/admin/reset", { method: "POST" });
    const data = await res.json();
    if (res.ok) {
      setContent(data);
      showToast("✅ Reset to defaults");
    }
  }

  async function handleLogout() {
    await fetch("/api/admin/logout", { method: "POST" });
    onLogout();
  }

  if (!content) {
    return <div className="admin-shell"><div className="admin-body">Loading…</div></div>;
  }

  const field = (path) => ({
    value: get(content, path) ?? "",
    onChange: (v) => setContent(set(content, path, v)),
  });

  return (
    <div className="admin-shell">
      <div className="admin-topbar">
        <strong>Temple Admin Panel</strong>
        <div style={{ display: "flex", gap: 12 }}>
          <button className="btn btn-outline" style={{ color: "#fff", borderColor: "rgba(255,255,255,.4)" }} onClick={handleReset}>
            Reset to Defaults
          </button>
          <button className="btn btn-gold" onClick={handleLogout}>Logout</button>
        </div>
      </div>

      <div className="admin-body">
        <div className="admin-tabs">
          {TABS.map((t) => (
            <button
              key={t.key}
              className={`admin-tab${tab === t.key ? " active" : ""}`}
              onClick={() => setTab(t.key)}
            >
              {t.label}
            </button>
          ))}
        </div>

        <div className="admin-panel">
          {tab === "hero" && (
            <SimpleEditor onSave={() => saveContent(content)}>
              <ImageUploader label="Hero Image" {...field("hero.image")} />
              <div className="f-field">
                <label>Welcome Message</label>
                <textarea rows={4} {...field("hero.welcome")} onChange={(e) => field("hero.welcome").onChange(e.target.value)} />
              </div>
            </SimpleEditor>
          )}

          {tab === "about" && (
            <SimpleEditor onSave={() => saveContent(content)}>
              <div className="f-field">
                <label>About Text</label>
                <textarea rows={6} value={get(content, "about.text")} onChange={(e) => setContent(set(content, "about.text", e.target.value))} />
              </div>
              <ImageUploader label="About Image" value={get(content, "about.image")} onChange={(v) => setContent(set(content, "about.image", v))} />
            </SimpleEditor>
          )}

          {tab === "history" && (
            <SimpleEditor onSave={() => saveContent(content)}>
              <div className="f-field">
                <label>History Text (blank line = new paragraph)</label>
                <textarea rows={8} value={get(content, "history.text")} onChange={(e) => setContent(set(content, "history.text", e.target.value))} />
              </div>
              <div className="f-field">
                <label>Spiritual Importance Text</label>
                <textarea rows={8} value={get(content, "importance.text")} onChange={(e) => setContent(set(content, "importance.text", e.target.value))} />
              </div>
            </SimpleEditor>
          )}

          {tab === "significance" && (
            <ArrayEditor
              items={content.significance.items}
              onChange={(items) => setContent(set(content, "significance.items", items))}
              onSave={() => saveContent(content)}
              newItem={{ icon: "🕉️", title: "New Item", body: "" }}
              renderItem={(item, update) => (
                <>
                  <div className="f-field"><label>Icon (emoji)</label><input value={item.icon} onChange={(e) => update({ ...item, icon: e.target.value })} /></div>
                  <div className="f-field"><label>Title</label><input value={item.title} onChange={(e) => update({ ...item, title: e.target.value })} /></div>
                  <div className="f-field"><label>Description</label><textarea rows={3} value={item.body} onChange={(e) => update({ ...item, body: e.target.value })} /></div>
                </>
              )}
            />
          )}

          {tab === "gallery" && (
            <ArrayEditor
              items={content.gallery}
              onChange={(items) => setContent(set(content, "gallery", items))}
              onSave={() => saveContent(content)}
              newItem={{ url: "", cap: "New Photo" }}
              renderItem={(item, update) => (
                <>
                  <ImageUploader label="Image" value={item.url} onChange={(v) => update({ ...item, url: v })} />
                  <div className="f-field"><label>Caption</label><input value={item.cap} onChange={(e) => update({ ...item, cap: e.target.value })} /></div>
                </>
              )}
            />
          )}

          {tab === "videos" && (
            <ArrayEditor
              items={content.videos}
              onChange={(items) => setContent(set(content, "videos", items))}
              onSave={() => saveContent(content)}
              newItem={{ type: "youtube", url: "", title: "New Video" }}
              renderItem={(item, update) => (
                <>
                  <div className="f-field">
                    <label>Type</label>
                    <select value={item.type} onChange={(e) => update({ ...item, type: e.target.value })}>
                      <option value="youtube">YouTube (embed URL)</option>
                      <option value="upload">Uploaded Video</option>
                    </select>
                  </div>
                  {item.type === "upload" ? (
                    <ImageUploader label="Video File" accept="video/*" value={item.url} onChange={(v) => update({ ...item, url: v })} />
                  ) : (
                    <div className="f-field"><label>YouTube Embed URL</label><input value={item.url} onChange={(e) => update({ ...item, url: e.target.value })} placeholder="https://www.youtube.com/embed/VIDEO_ID" /></div>
                  )}
                  <div className="f-field"><label>Title</label><input value={item.title} onChange={(e) => update({ ...item, title: e.target.value })} /></div>
                </>
              )}
            />
          )}

          {tab === "festivals" && (
            <ArrayEditor
              items={content.festivals}
              onChange={(items) => setContent(set(content, "festivals", items))}
              onSave={() => saveContent(content)}
              newItem={{ icon: "🪔", name: "New Festival", date: "", desc: "" }}
              renderItem={(item, update) => (
                <>
                  <div className="f-field"><label>Icon (emoji)</label><input value={item.icon} onChange={(e) => update({ ...item, icon: e.target.value })} /></div>
                  <div className="f-field"><label>Name</label><input value={item.name} onChange={(e) => update({ ...item, name: e.target.value })} /></div>
                  <div className="f-field"><label>Date / Timing</label><input value={item.date} onChange={(e) => update({ ...item, date: e.target.value })} /></div>
                  <div className="f-field"><label>Description</label><textarea rows={3} value={item.desc} onChange={(e) => update({ ...item, desc: e.target.value })} /></div>
                </>
              )}
            />
          )}

          {tab === "updates" && (
            <ArrayEditor
              items={content.updates}
              onChange={(items) => setContent(set(content, "updates", items))}
              onSave={() => saveContent(content)}
              newItem={{ day: "01", mon: "Jan", tag: "Announcement", title: "New Update", text: "" }}
              renderItem={(item, update) => (
                <>
                  <div style={{ display: "flex", gap: 12 }}>
                    <div className="f-field" style={{ flex: 1 }}><label>Day</label><input value={item.day} onChange={(e) => update({ ...item, day: e.target.value })} /></div>
                    <div className="f-field" style={{ flex: 1 }}><label>Month</label><input value={item.mon} onChange={(e) => update({ ...item, mon: e.target.value })} /></div>
                  </div>
                  <div className="f-field"><label>Tag</label><input value={item.tag} onChange={(e) => update({ ...item, tag: e.target.value })} /></div>
                  <div className="f-field"><label>Title</label><input value={item.title} onChange={(e) => update({ ...item, title: e.target.value })} /></div>
                  <div className="f-field"><label>Text</label><textarea rows={2} value={item.text} onChange={(e) => update({ ...item, text: e.target.value })} /></div>
                </>
              )}
            />
          )}

          {tab === "donations" && (
            <SimpleEditor onSave={() => saveContent(content)}>
              <div className="f-field">
                <label>
                  <input
                    type="checkbox"
                    checked={!get(content, "donations.hidden")}
                    onChange={(e) => setContent(set(content, "donations.hidden", !e.target.checked))}
                    style={{ width: "auto", marginRight: 8 }}
                  />
                  Show donations section on the site
                </label>
              </div>
              <div className="f-field"><label>UPI ID</label><input value={get(content, "donations.upi")} onChange={(e) => setContent(set(content, "donations.upi", e.target.value))} /></div>
              <ImageUploader label="QR Code Image" value={get(content, "donations.qr")} onChange={(v) => setContent(set(content, "donations.qr", v))} />
              <div className="f-field"><label>Description</label><textarea rows={4} value={get(content, "donations.text")} onChange={(e) => setContent(set(content, "donations.text", e.target.value))} /></div>
            </SimpleEditor>
          )}

          {tab === "phones" && (
            <ArrayEditor
              items={content.phones}
              onChange={(items) => setContent(set(content, "phones", items))}
              onSave={() => saveContent(content)}
              newItem={{ label: "New Number", number: "+91 00000 00000", desc: "", whatsapp: "" }}
              renderItem={(item, update) => (
                <>
                  <div className="f-field"><label>Label</label><input value={item.label} onChange={(e) => update({ ...item, label: e.target.value })} /></div>
                  <div className="f-field"><label>Phone Number</label><input value={item.number} onChange={(e) => update({ ...item, number: e.target.value })} /></div>
                  <div className="f-field"><label>Description</label><input value={item.desc} onChange={(e) => update({ ...item, desc: e.target.value })} /></div>
                  <div className="f-field"><label>WhatsApp Number (91XXXXXXXXXX) or wa.me URL</label><input value={item.whatsapp} onChange={(e) => update({ ...item, whatsapp: e.target.value })} /></div>
                </>
              )}
            />
          )}

          {tab === "contact" && (
            <SimpleEditor onSave={() => saveContent(content)}>
              <div className="f-field"><label>Email Address</label><input type="email" value={get(content, "contact.email")} onChange={(e) => setContent(set(content, "contact.email", e.target.value))} /></div>
              <div className="f-field"><label>Full Address</label><textarea rows={3} value={get(content, "contact.address")} onChange={(e) => setContent(set(content, "contact.address", e.target.value))} /></div>
              <div className="f-field"><label>Visiting Hours</label><input value={get(content, "contact.hours")} onChange={(e) => setContent(set(content, "contact.hours", e.target.value))} /></div>
            </SimpleEditor>
          )}

          {tab === "location" && (
            <SimpleEditor onSave={() => saveContent(content)}>
              <div className="f-field"><label>Temple Address</label><textarea rows={2} value={get(content, "location.address")} onChange={(e) => setContent(set(content, "location.address", e.target.value))} /></div>
              <div className="f-field"><label>Nearest Landmark</label><input value={get(content, "location.landmark")} onChange={(e) => setContent(set(content, "location.landmark", e.target.value))} /></div>
              <div className="f-field">
                <label>Google Maps Embed URL</label>
                <input value={get(content, "location.map")} onChange={(e) => setContent(set(content, "location.map", e.target.value))} placeholder="https://www.google.com/maps?q=...&output=embed" />
                <div style={{ fontSize: 12, color: "var(--muted)", marginTop: 4 }}>In Google Maps → Share → Embed a map → copy the src= URL.</div>
              </div>
              <div className="f-field"><label>Directions Link</label><input value={get(content, "location.directions")} onChange={(e) => setContent(set(content, "location.directions", e.target.value))} /></div>
            </SimpleEditor>
          )}

          {tab === "theme" && (
            <SimpleEditor onSave={() => saveContent(content)}>
              <p style={{ fontSize: 13, color: "var(--muted)", marginBottom: 18 }}>
                Adjust the site color palette. Changes apply after saving.
              </p>
              <div className="color-grid">
                {[
                  ["primary", "Primary"], ["primary2", "Primary Accent"], ["gold", "Gold Accent"],
                  ["stone", "Dark Stone"], ["stone2", "Stone Mid"], ["cream", "Cream Background"],
                  ["sand", "Sand (alt sections)"], ["border", "Border Color"], ["muted", "Muted Text"],
                ].map(([key, label]) => (
                  <div key={key}>
                    <div className="clr-lbl">{label}</div>
                    <input
                      type="color"
                      value={get(content, `theme.${key}`) || "#8B1A1A"}
                      onChange={(e) => setContent(set(content, `theme.${key}`, e.target.value))}
                      style={{ width: "100%", height: 44, borderRadius: 8, border: "2px solid var(--border)", padding: 3 }}
                    />
                  </div>
                ))}
              </div>
            </SimpleEditor>
          )}

          {tab === "messages" && (
            <div>
              <h3 style={{ marginBottom: 16 }}>Contact Form Submissions</h3>
              {messages.length === 0 ? (
                <p style={{ color: "var(--muted)" }}>No messages yet.</p>
              ) : (
                messages.map((m) => (
                  <div className="row-card" key={m.id}>
                    <strong>{m.name}</strong>{" "}
                    <span style={{ fontSize: 12, color: "var(--muted)" }}>
                      {new Date(m.createdAt).toLocaleString()}
                    </span>
                    <div style={{ fontSize: 13, color: "var(--muted)", margin: "4px 0" }}>
                      {[m.email, m.phone].filter(Boolean).join(" · ")}
                    </div>
                    <p style={{ fontSize: 14 }}>{m.message}</p>
                  </div>
                ))
              )}
            </div>
          )}

          {tab === "password" && <PasswordEditor onDone={() => showToast("✅ Password changed")} />}
        </div>
      </div>

      <div className={`toast${toast ? " show" : ""}`}>{toast}</div>
    </div>
  );
}

function SimpleEditor({ children, onSave }) {
  return (
    <div>
      {children}
      <button className="save-btn" onClick={onSave}>💾 Save Changes</button>
    </div>
  );
}

function ArrayEditor({ items, onChange, onSave, newItem, renderItem }) {
  function update(i, next) {
    const clone = [...items];
    clone[i] = next;
    onChange(clone);
  }
  function remove(i) {
    onChange(items.filter((_, idx) => idx !== i));
  }
  function add() {
    onChange([...items, structuredClone(newItem)]);
  }

  return (
    <div>
      {items.map((item, i) => (
        <div className="row-card" key={i}>
          <button className="row-remove" onClick={() => remove(i)}>✕ Remove</button>
          {renderItem(item, (next) => update(i, next))}
        </div>
      ))}
      <button className="add-row-btn" onClick={add}>+ Add New</button>
      <button className="save-btn" onClick={onSave}>💾 Save Changes</button>
    </div>
  );
}

function PasswordEditor({ onDone }) {
  const [p1, setP1] = useState("");
  const [p2, setP2] = useState("");
  const [error, setError] = useState("");

  async function handleSave() {
    setError("");
    if (!p1) return setError("Password cannot be empty.");
    if (p1 !== p2) return setError("Passwords do not match.");
    const res = await fetch("/api/admin/password", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ newPassword: p1 }),
    });
    const data = await res.json();
    if (!res.ok) return setError(data.error || "Failed to change password");
    setP1(""); setP2("");
    onDone();
  }

  return (
    <div>
      <div className="f-field"><label>New Password</label><input type="password" value={p1} onChange={(e) => setP1(e.target.value)} /></div>
      <div className="f-field"><label>Confirm Password</label><input type="password" value={p2} onChange={(e) => setP2(e.target.value)} /></div>
      {error && <p style={{ color: "var(--primary2)", fontSize: 13, marginBottom: 12 }}>{error}</p>}
      <button className="save-btn" onClick={handleSave}>💾 Change Password</button>
    </div>
  );
}
