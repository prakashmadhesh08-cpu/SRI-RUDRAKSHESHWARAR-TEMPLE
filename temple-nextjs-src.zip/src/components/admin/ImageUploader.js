"use client";

import { useRef, useState } from "react";

export default function ImageUploader({ value, onChange, label = "Image", accept = "image/*" }) {
  const inputRef = useRef(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function handleFile(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setBusy(true);
    setError("");
    try {
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch("/api/upload", { method: "POST", body: fd });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Upload failed");
      onChange(data.url);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  }

  return (
    <div className="f-field">
      <label>{label}</label>
      {value && accept.startsWith("image") && (
        <img src={value} alt="" style={{ maxWidth: 160, borderRadius: 8, marginBottom: 8 }} />
      )}
      <div style={{ display: "flex", gap: 8 }}>
        <input
          type="text"
          value={value || ""}
          onChange={(e) => onChange(e.target.value)}
          placeholder="Image/video URL, or upload a file"
          style={{ flex: 1 }}
        />
        <input ref={inputRef} type="file" accept={accept} onChange={handleFile} style={{ display: "none" }} />
        <button
          type="button"
          className="btn btn-outline"
          onClick={() => inputRef.current?.click()}
          disabled={busy}
          style={{ padding: "10px 14px", whiteSpace: "nowrap" }}
        >
          {busy ? "Uploading…" : "Upload"}
        </button>
      </div>
      {error && <div style={{ color: "var(--primary2)", fontSize: 12, marginTop: 4 }}>{error}</div>}
    </div>
  );
}
